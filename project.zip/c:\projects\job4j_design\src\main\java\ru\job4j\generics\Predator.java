package ru.job4j.generics;

public class Predator extends Animal {

    @Override
    public String toString() {
        return "Predator{}";
    }
}
